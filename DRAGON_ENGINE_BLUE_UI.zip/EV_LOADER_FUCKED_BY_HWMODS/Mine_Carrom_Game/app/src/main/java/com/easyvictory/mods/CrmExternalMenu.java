package com.easyvictory.mods;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.Html;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Activity-owned loader UI with exact same design, styling, and behavior
 * as the original Mine_Carrom_Game mod menu (Menu.java).
 */
public final class CrmExternalMenu {

    // ========== Visual Constants (Identical to Menu.java) ==========
    private static final int TEXT_COLOR = EvIcons.TEXT_WHITE;
    private static final int TEXT_COLOR_2 = EvIcons.GOLD;
    private static final int BTN_COLOR = EvIcons.GOLD;
    private static final int SURFACE_COLOR = EvIcons.SURFACE;
    private static final int BORDER_COLOR = EvIcons.BORDER_GOLD;
    private static final int MUTED_COLOR = EvIcons.TEXT_SUBTLE;
    private static final int MENU_BG_COLOR = EvIcons.BG_DARK;
    private static final int MENU_WIDTH = 320;
    private static final int MENU_HEIGHT = 350;
    private static final int ICON_SIZE = 45;
    private int logoOpacity = 85;
    private static final int ToggleON = EvIcons.GOLD;
    private static final int ToggleOFF = EvIcons.SWITCH_OFF_THUMB;
    private static final int SeekBarColor = EvIcons.GOLD;
    private static final int SeekBarProgressColor = EvIcons.GOLD;
    private static final String NumberTxtColor = "#38BDF8";

    // ========== Core Infrastructure ==========
    private final Context owner;
    private final Bridge bridge;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ScheduledExecutorService worker = Executors.newSingleThreadScheduledExecutor(task -> {
        Thread thread = new Thread(task, "crm-loader-session");
        thread.setDaemon(true);
        return thread;
    });
    private final AtomicLong authEpoch = new AtomicLong();
    private final List<Runnable> refreshers = new ArrayList<>();
    private final List<Button> tabButtons = new ArrayList<>();
    private final List<LinearLayout> categoryPages = new ArrayList<>();

    private volatile boolean closed;
    private volatile boolean loginPending;
    private volatile boolean renewEnabled;
    private volatile boolean foreground;
    private boolean syncing;
    private boolean featuresVisible;
    private boolean menuFailed;
    private boolean expanded = true;
    private int selectedTab = 0;
    private String message = "Enter your license key to authenticate.";

    // Active views
    private Activity activity;
    private FrameLayout root;
    private LinearLayout panel;
    private RelativeLayout bubble;
    private Button floatingQueue;
    private EvIcons.HeaderViews headerViews;
    private EvIcons.LicenseViews licenseViews;
    private final LinearLayout[] groupHolders = new LinearLayout[3];
    private LinearLayout globalControls;
    private LinearLayout categoryTabs;
    private ScrollView scrollView;
    private LinearLayout patches;
    private LinearLayout settingsView;
    private LinearLayout loginContainer;
    private EditText keyInput;
    private Button pasteBtn;
    private Button loginBtn;
    private Button getKeyBtn;
    private Button joinTgBtn;
    private TextView statusText;

    // Active running animators
    private ValueAnimator cardBorderAnim;
    private ValueAnimator titleGlowAnim;
    private ValueAnimator pulseAnim;

    // Native Bridge
    public static final class Bridge extends ContextWrapper {
        Bridge(Context context) { super(context); }
        private static void loadLibrary(String path) {
            if (path != null) {
                java.io.File libFile = new java.io.File(path);
                java.io.File parent = libFile.getParentFile();
                if (parent != null && !"libHwMods.so".equals(libFile.getName())) {
                    java.io.File hwm = new java.io.File(parent, "libHwMods.so");
                    if (hwm.isFile()) {
                        System.load(hwm.getAbsolutePath());
                    }
                }
                System.load(path);
            }
        }
        native void nativeStartGameEngine();
        native void setTitleText(TextView view);
        native void setHeadingText(TextView view);
        native String Icon();
        native String IconWebViewData();
        native String[] getFeatureList();
        native String[] settingsList();
        native String getFeatureStatus(int feature);
        native int getFeatureValue(int feature);
        native boolean isGameLibLoaded();
        native String nativeCheckKey(Context context, String key);
        native String nativeRenewKey(Context context);
        native boolean isKeyAuthenticated();
        native boolean isLoginEnabled();
        native String getExpiryDate();
        native String getModStatus();
        native String getModCredit();
        native String getModName();
        native String getModSubtitle();
        native String getTelegramHandle();
        native String getTelegramUrl();
        native String getBuyKeyUrl();
        native String getFreeKeyUrl();
        native String getLoginTitle();
        native String getLoginBanner();
        native String getStatusBadge();
        native void nativeSetFreeMode(boolean freeMode);
        native void Changes(Context context, int id, String label, int value, boolean enabled, String text);
    }

    public static void loadNativeLibrary(String path) {
        Bridge.loadLibrary(path);
    }

    public CrmExternalMenu(Context loaderContext) {
        Context appCtx = loaderContext != null ? loaderContext.getApplicationContext() : null;
        owner = appCtx != null ? appCtx : loaderContext;
        String pkg = owner != null ? owner.getPackageName() : null;
        if (!"com.easyvictory.mods".equals(pkg) && !"com.hwmods.loader".equals(pkg) && !"com.miniclip.carrom".equals(pkg)) {
            throw new IllegalArgumentException("Wrong loader context: " + pkg);
        }
        bridge = new Bridge(owner);
        logoOpacity = Math.max(10, Math.min(100,
                owner.getSharedPreferences("loader_appearance", Context.MODE_PRIVATE).getInt("logo_opacity", 75)));
        bridge.isKeyAuthenticated(); // Fail immediately if incompatible SO was supplied
        bridge.nativeStartGameEngine();

        // Periodic session renewal (every 45 seconds)
        worker.scheduleWithFixedDelay(() -> {
            if (closed || !foreground || !renewEnabled) return;
            final long epoch = authEpoch.get();
            boolean valid = false;
            try {
                String result = bridge.nativeRenewKey(owner);
                valid = result != null && result.startsWith("OK|") && bridge.isKeyAuthenticated();
            } catch (RuntimeException | LinkageError ignored) { }
            if (!valid && epoch == authEpoch.get()) {
                renewEnabled = false;
                postMessage("Session expired. Please log in again.");
                main.post(() -> {
                    if (!closed && foreground) {
                        showLoginView();
                    }
                });
            }
        }, 45, 45, TimeUnit.SECONDS);
    }

    /** Attach to the resumed Carrom Activity */
    public void attach(Activity current) {
        requireMain();
        if (closed || current.isFinishing() || current.isDestroyed() ||
                !"com.miniclip.carrom".equals(current.getPackageName())) return;
        if (activity == current && root != null) return;
        detach(activity);
        activity = current;
        foreground = true;

        root = new FrameLayout(current);
        root.setClipChildren(false);
        root.setClickable(false);

        // Build Menu Window Panel
        buildMenuPanel(current);

        // Build Collapsed Floating Icon & Auto-Queue Button
        buildCollapsedBubble(current);

        // Add root view to Activity decor view
        ((ViewGroup) current.getWindow().getDecorView()).addView(root,
                new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        setExpanded(expanded);

        if (!bridge.isLoginEnabled() || bridge.isKeyAuthenticated()) {
            showFeaturesView();
        } else {
            showLoginView();
        }

        main.post(poll);
    }

    public void detach(Activity current) {
        requireMain();
        if (activity != current) return;
        foreground = false;
        main.removeCallbacks(poll);
        stopAnimators();
        if (root != null && root.getParent() instanceof ViewGroup) {
            ((ViewGroup) root.getParent()).removeView(root);
        }
        refreshers.clear();
        tabButtons.clear();
        categoryPages.clear();
        root = null;
        panel = null;
        bubble = null;
        floatingQueue = null;
        headerViews = null;
        licenseViews = null;
        for (int i = 0; i < groupHolders.length; ++i) groupHolders[i] = null;
        globalControls = null;
        categoryTabs = null;
        scrollView = null;
        patches = null;
        settingsView = null;
        loginContainer = null;
        keyInput = null;
        pasteBtn = null;
        loginBtn = null;
        getKeyBtn = null;
        joinTgBtn = null;
        statusText = null;
        activity = null;
    }

    public void close() {
        requireMain();
        closed = true;
        renewEnabled = false;
        authEpoch.incrementAndGet();
        bridge.nativeSetFreeMode(false);
        worker.shutdownNow();
        detach(activity);
        main.removeCallbacksAndMessages(null);
    }

    // ============================================================
    //  UI CONSTRUCTION (Identical to Menu.java)
    // ============================================================

    private void buildMenuPanel(Activity current) {
        panel = column();
        panel.setOrientation(LinearLayout.VERTICAL);

        // Background: 26dp rounded rectangle with dark gold gradient and border
        panel.setBackground(EvIcons.createMenuPanelBackground(current));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            panel.setElevation(dp(12));
        }

        int availableWidth = current.getResources().getDisplayMetrics().widthPixels - dp(16);
        int menuWidth = Math.min(dp(MENU_WIDTH), availableWidth);
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(menuWidth, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.START);
        pp.leftMargin = dp(12);
        pp.topMargin = dp(52);
        root.addView(panel, pp);

        // 1. Centered Mod Logo, Name & Expiry
        headerViews = EvIcons.createHeader(current, bridge.Icon(), bridge.getModName(), safeString(2),
                v -> setExpanded(false),
                v -> {
                    setExpanded(false);
                    if (bubble != null) bubble.setAlpha(0f);
                    Toast.makeText(v.getContext(), "Icon hidden. Remember the hidden icon position", Toast.LENGTH_LONG).show();
                    return true;
                },
                () -> close());
        licenseViews = EvIcons.createLicenseStrip(current, safeString(0), safeString(1));
        panel.addView(headerViews.root);
        panel.addView(licenseViews.root);
        enableDrag(headerViews.logo != null ? headerViews.logo : headerViews.root, panel);
        updateMenuExpiryText();

        // 2. Tab bar (AIM, TOOLS, SETTINGS)
        categoryTabs = new LinearLayout(current);
        categoryTabs.setOrientation(LinearLayout.HORIZONTAL);
        categoryTabs.setPadding(dp(9), dp(2), dp(9), dp(6));
        categoryTabs.setVisibility(View.GONE);
        panel.addView(categoryTabs);

        // 3. Global Controls Container
        globalControls = new LinearLayout(current);
        globalControls.setOrientation(LinearLayout.VERTICAL);
        globalControls.setPadding(dp(12), 0, dp(12), dp(4));
        globalControls.setVisibility(View.GONE);
        panel.addView(globalControls);

        // 4. ScrollView with Dynamic Height
        scrollView = new ScrollView(current);
        int usableBody = Math.max(dp(96), current.getResources().getDisplayMetrics().heightPixels - dp(300));
        LinearLayout.LayoutParams scrlParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Math.min(dp(MENU_HEIGHT), usableBody));
        scrollView.setLayoutParams(scrlParams);
        scrollView.setBackgroundColor(Color.TRANSPARENT);
        scrollView.setFillViewport(true);
        scrollView.setVerticalScrollBarEnabled(false);
        scrollView.setClipToPadding(false);
        scrollView.setPadding(dp(4), 0, dp(4), dp(4));

        patches = new LinearLayout(current);
        patches.setOrientation(LinearLayout.VERTICAL);
        patches.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        panel.addView(scrollView);

        // 5. Footer (version and credit)
        panel.addView(EvIcons.createBrandFooter(current, bridge.getModName(), safeString(3)));
    }

    private void buildCollapsedBubble(Activity current) {
        bubble = new RelativeLayout(current);
        bubble.setClipChildren(false);

        ImageView startimage = new ImageView(current);
        startimage.setId(View.generateViewId());
        int iconSizePx = dp(ICON_SIZE);
        RelativeLayout.LayoutParams logoParams = new RelativeLayout.LayoutParams(iconSizePx, iconSizePx);
        logoParams.addRule(RelativeLayout.CENTER_HORIZONTAL);
        startimage.setLayoutParams(logoParams);
        startimage.setScaleType(ImageView.ScaleType.FIT_CENTER);
        // Alpha is applied to the parent bubble once, as in the original menu.
        String nativeIcon = null;
        try {
            nativeIcon = bridge.Icon();
        } catch (Throwable ignored) {
        }
        android.graphics.drawable.Drawable brand = EvIcons.brandLogo(current, nativeIcon);
        if (brand != null) startimage.setImageDrawable(brand);
        else startimage.setImageResource(android.R.drawable.ic_menu_view);
        startimage.setContentDescription("Open Carrom mod menu. Drag to move.");
        startimage.setOnClickListener(v -> setExpanded(true));
        bubble.addView(startimage);

        // Floating Auto-Play Icon Button directly below icon
        floatingQueue = new Button(current);
        floatingQueue.setAllCaps(false);
        floatingQueue.setText("");
        floatingQueue.setPadding(0, 0, 0, 0);
        floatingQueue.setMinWidth(0);
        floatingQueue.setMinimumWidth(0);
        floatingQueue.setMinHeight(0);
        floatingQueue.setMinimumHeight(0);
        floatingQueue.setBackground(null);
        RelativeLayout.LayoutParams queueParams = new RelativeLayout.LayoutParams(dp(36), dp(36));
        queueParams.addRule(RelativeLayout.BELOW, startimage.getId());
        queueParams.addRule(RelativeLayout.CENTER_HORIZONTAL);
        queueParams.topMargin = dp(12);
        floatingQueue.setLayoutParams(queueParams);

        refreshQueueControls();

        floatingQueue.setOnClickListener(v -> {
            if (bridge.isLoginEnabled() && !bridge.isKeyAuthenticated()) {
                setExpanded(true);
                return;
            }
            boolean enable = bridge.getFeatureValue(13) == 0;
            if (enable) {
                change(CrmFeatureSpec.parse("13_NativeSpinner_Autoplay_Off,V1,V2,V3"), 2, false);
                change(CrmFeatureSpec.parse("16_NativeSpinner_Clean Table_Off,Own Pucks,Aggressive"), 1, false);
                change(CrmFeatureSpec.parse("14_SeekBar_Scanner Depth_1_5_5"), 5, false);
                change(CrmFeatureSpec.parse("15_SeekBar_Shot Force_5_100_60"), 100, false);
            } else {
                change(CrmFeatureSpec.parse("13_NativeSpinner_Autoplay_Off,V1,V2,V3"), 0, false);
            }
            change(CrmFeatureSpec.parse("19_Toggle_Auto Queue"), 0, false);
            refreshQueueControls();
            Toast.makeText(activity, enable ? "Auto Play V2 / Natural on" : "Auto Play off", Toast.LENGTH_SHORT).show();
        });
        bubble.addView(floatingQueue);

        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(dp(ICON_SIZE + 10), dp(104), Gravity.TOP | Gravity.START);
        bp.leftMargin = dp(12);
        bp.topMargin = dp(52);
        root.addView(bubble, bp);

        enableDrag(startimage, bubble);
    }

    private void refreshQueueControls() {
        if (floatingQueue == null || activity == null) return;
        boolean authenticated = !bridge.isLoginEnabled() || bridge.isKeyAuthenticated();
        final boolean on = bridge.getFeatureValue(13) != 0;
        floatingQueue.setVisibility(authenticated ? View.VISIBLE : View.GONE);
        EvIcons.applyQueueButtonStyle(activity, floatingQueue, on);
    }

    // ============================================================
    //  LOGIN VIEW (EXACT SAME AS Menu.java)
    // ============================================================

    private void showLoginView() {
        if (!bridge.isLoginEnabled()) {
            showFeaturesView();
            return;
        }
        if (activity == null || closed) return;
        featuresVisible = false;
        if (categoryTabs != null) categoryTabs.setVisibility(View.GONE);
        if (globalControls != null) globalControls.setVisibility(View.GONE);
        updateMenuExpiryText();
        if (scrollView == null) return;
        scrollView.removeAllViews();
        if (loginContainer == null) {
            initLoginView();
        }
        scrollView.addView(loginContainer);
    }

    private void initLoginView() {
        stopAnimators();
        EditText[] keyRef = new EditText[1];
        Button[] pasteRef = new Button[1];
        Button[] loginRef = new Button[1];
        TextView[] statusRef = new TextView[1];
        loginContainer = EvIcons.createLoginContainer(
                activity,
                message,
                bridge.getStatusBadge(),
                bridge.getLoginTitle(),
                bridge.getLoginBanner(),
                bridge.getBuyKeyUrl(),
                bridge.getFreeKeyUrl(),
                bridge.getTelegramUrl(),
                keyRef, pasteRef, loginRef, statusRef);
        keyInput = keyRef[0];
        pasteBtn = pasteRef[0];
        loginBtn = loginRef[0];
        statusText = statusRef[0];

        // Keystore work must not stall the game's UI thread or replace typed input.
        final EditText field = keyInput;
        worker.execute(() -> {
            String savedKey = CrmKeyStore.read(owner);
            main.post(() -> {
                if (!closed && keyInput == field && field.length() == 0 && savedKey != null && !savedKey.isEmpty())
                    field.setText(savedKey);
            });
        });

        if (loginBtn != null) {
            loginBtn.setOnClickListener(v -> performKeyLogin(false));
        }
    }

    private void performKeyLogin(final boolean isAutoLogin) {
        if (closed || menuFailed || loginPending) return;
        final String key = keyInput != null ? keyInput.getText().toString().trim() : CrmKeyStore.read(owner);
        if (key == null || key.isEmpty()) {
            playShakeAnimation(loginContainer);
            if (statusText != null) {
                statusText.setTextColor(EvIcons.ERROR_RED);
                statusText.setText("Please enter a valid license key.");
            }
            if (!isAutoLogin) {
                Toast.makeText(activity, "Please enter a license key", Toast.LENGTH_SHORT).show();
            }
            return;
        }

        loginPending = true;
        renewEnabled = false;
        final long loginEpoch = authEpoch.incrementAndGet();
        bridge.nativeSetFreeMode(false);

        if (statusText != null) {
            statusText.setTextColor(EvIcons.GOLD);
            statusText.setText("Connecting to server...");
        }
        if (loginBtn != null) {
            loginBtn.setEnabled(false);
            loginBtn.setText("VERIFYING...");
            loginBtn.setTextColor(EvIcons.TEXT_ON_GOLD);
            loginBtn.setAlpha(0.7f);
        }

        worker.execute(() -> {
            if (closed || loginEpoch != authEpoch.get()) return;
            String result;
            try {
                result = bridge.nativeCheckKey(owner, key);
                if (!closed && loginEpoch == authEpoch.get() && result != null &&
                        result.startsWith("OK|") && bridge.isKeyAuthenticated())
                    CrmKeyStore.write(owner, key);
            } catch (RuntimeException | LinkageError failure) {
                result = "ERR|Login unavailable";
            }
            final String res = result;

            main.post(() -> {
                loginPending = false;
                if (closed || loginEpoch != authEpoch.get() || activity == null) return;

                if (loginBtn != null) {
                    loginBtn.setEnabled(true);
                    loginBtn.setText("LOGIN");
                    loginBtn.setTextColor(EvIcons.TEXT_ON_GOLD);
                    loginBtn.setAlpha(1.0f);
                }

                if (res != null && res.startsWith("OK|") && bridge.isKeyAuthenticated()) {
                    renewEnabled = true;
                    String exp = bridge.getExpiryDate();
                    if (statusText != null) {
                        statusText.setTextColor(EvIcons.GOLD);
                        statusText.setText("Signed in \u00B7 Expires: " + exp);
                    }
                    Toast.makeText(activity, "Welcome! " + bridge.getModName() + " Unlocked (Exp: " + exp + ")", Toast.LENGTH_LONG).show();
                    animateAuthenticatedFeatures();
                } else {
                    playShakeAnimation(loginContainer);
                    String reason = res != null ? (res.startsWith("ERR|") ? res.substring(4) : res) : "Unknown Error";
                    if (statusText != null) {
                        statusText.setTextColor(EvIcons.ERROR_RED);
                        statusText.setText("AUTHENTICATION FAILED: " + reason);
                    }
                    if (!isAutoLogin) {
                        Toast.makeText(activity, "Auth Failed: " + reason, Toast.LENGTH_LONG).show();
                    }
                }
            });
        });
    }

    private void animateAuthenticatedFeatures() {
        updateMenuExpiryText();
        refreshQueueControls();
        if (loginContainer == null) {
            showFeaturesView();
            return;
        }

        AnimationSet fadeOut = new AnimationSet(true);
        fadeOut.addAnimation(new AlphaAnimation(1.0f, 0.0f));
        fadeOut.addAnimation(new ScaleAnimation(1.0f, 0.95f, 1.0f, 0.95f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f));
        fadeOut.setDuration(400);

        final long uiEpoch = authEpoch.get();
        fadeOut.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationEnd(Animation animation) {
                if (closed || uiEpoch != authEpoch.get() || !bridge.isKeyAuthenticated()) return;
                showFeaturesView();
                if (patches != null) {
                    AnimationSet fadeIn = new AnimationSet(true);
                    fadeIn.addAnimation(new AlphaAnimation(0.0f, 1.0f));
                    fadeIn.addAnimation(new TranslateAnimation(0, 0, dp(15), 0));
                    fadeIn.setDuration(350);
                    fadeIn.setInterpolator(new DecelerateInterpolator());
                    patches.startAnimation(fadeIn);
                }
            }
            @Override public void onAnimationStart(Animation a) {}
            @Override public void onAnimationRepeat(Animation a) {}
        });
        loginContainer.startAnimation(fadeOut);
    }

    // ============================================================
    //  FEATURES VIEW & TABS (Identical to Menu.java)
    // ============================================================

    private void showFeaturesView() {
        if (activity == null || closed) return;
        if (bridge.isLoginEnabled() && !bridge.isKeyAuthenticated()) {
            showLoginView();
            return;
        }

        featuresVisible = true;
        updateMenuExpiryText();
        refreshQueueControls();

        if (scrollView == null) return;
        scrollView.removeAllViews();
        refreshers.clear();
        tabButtons.clear();
        categoryPages.clear();

        if (globalControls != null) {
            globalControls.removeAllViews();
            globalControls.setVisibility(View.VISIBLE);
        }
        if (categoryTabs != null) {
            categoryTabs.removeAllViews();
            categoryTabs.setVisibility(View.VISIBLE);
        }

        patches = column();
        patches.setOrientation(LinearLayout.VERTICAL);

        LinearLayout pageHolder = column();
        patches.addView(pageHolder);
        ensureGroupHolders(pageHolder);

        LinearLayout page = null;
        for (String raw : bridge.getFeatureList()) {
            CrmFeatureSpec spec = CrmFeatureSpec.parse(raw);
            if ("Tab".equals(spec.type)) {
                page = addCategory(spec.label, pageHolder);
            } else if (spec.global && globalControls != null) {
                control(globalControls, spec);
            } else if (page != null) {
                control(page, spec);
            }
        }

        // SETTINGS tab (built in Java)
        buildSettingsView();

        scrollView.addView(patches);
        selectCategory(Math.min(selectedTab, groupHolders.length - 1));
        refreshQueueControls();
    }

    // The UI shows three tabs (AIM, TOOLS, SETTINGS). Native tabs from getFeatureList()
    // become sections inside AIM or TOOLS; feature ids and callbacks are unchanged.
    private void ensureGroupHolders(LinearLayout parent) {
        for (int i = 0; i < groupHolders.length; ++i) {
            final int index = i;
            LinearLayout holder = new LinearLayout(activity);
            holder.setOrientation(LinearLayout.VERTICAL);
            holder.setVisibility(index == selectedTab ? View.VISIBLE : View.GONE);
            parent.addView(holder);
            groupHolders[i] = holder;
            Button tab = EvIcons.createTabButton(activity, EvTabs.TITLES[i], index == selectedTab);
            tab.setOnClickListener(v -> selectCategory(index));
            if (categoryTabs != null) {
                categoryTabs.addView(tab);
            }
            tabButtons.add(tab);
        }
    }

    private LinearLayout addCategory(String title, LinearLayout parent) {
        LinearLayout holder = groupHolders[EvTabs.groupFor(title)];
        int order = EvTabs.orderFor(title);
        LinearLayout page = new LinearLayout(activity);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(8), dp(2), dp(8), dp(6));
        page.setTag(Integer.valueOf(order));
        page.addView(EvIcons.createSectionLabel(activity, title.toUpperCase(Locale.US)));
        int insertAt = holder.getChildCount();
        for (int i = 0; i < holder.getChildCount(); ++i) {
            Object other = holder.getChildAt(i).getTag();
            if (other instanceof Integer && ((Integer) other) > order) {
                insertAt = i;
                break;
            }
        }
        holder.addView(page, insertAt);
        categoryPages.add(page);
        return page;
    }

    private void selectCategory(int index) {
        if (index < 0 || index >= groupHolders.length || groupHolders[index] == null) return;
        selectedTab = index;
        for (int i = 0; i < groupHolders.length; ++i) {
            if (groupHolders[i] == null) continue;
            groupHolders[i].setVisibility(i == index ? View.VISIBLE : View.GONE);
            if (i < tabButtons.size()) EvIcons.styleTabButton(activity, tabButtons.get(i), i == index);
        }
        if (scrollView != null) {
            scrollView.scrollTo(0, 0);
            scrollView.post(() -> { if (scrollView != null) scrollView.scrollTo(0, 0); });
        }
    }

    private void buildSettingsView() {
        settingsView = column();
        settingsView.setOrientation(LinearLayout.VERTICAL);
        String buyUrl = bridge.isLoginEnabled() ? safeString(4) : null;
        settingsView.addView(EvIcons.createSettingsPage(activity, logoOpacity,
                new SeekBar.OnSeekBarChangeListener() {
                    @Override public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                        if (!fromUser) return;
                        logoOpacity = value + 10;
                        if (bubble != null) bubble.setAlpha(logoAlpha());
                    }
                    @Override public void onStartTrackingTouch(SeekBar bar) { }
                    @Override public void onStopTrackingTouch(SeekBar bar) {
                        owner.getSharedPreferences("loader_appearance", Context.MODE_PRIVATE)
                                .edit().putInt("logo_opacity", logoOpacity).apply();
                    }
                },
                safeString(0), safeString(1), buyUrl, safeString(3)));

        // Log out Button (shown only when login is enabled; behavior unchanged)
        if (bridge.isLoginEnabled()) {
            Button logoutBtn = new Button(activity);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
            lp.setMargins(dp(8), dp(4), dp(8), dp(8));
            logoutBtn.setLayoutParams(lp);
            logoutBtn.setText("Log out");
            logoutBtn.setAllCaps(false);
            logoutBtn.setTextColor(Color.parseColor("#FF5252"));
            logoutBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.0f);
            logoutBtn.setBackground(cardBackground(SURFACE_COLOR, Color.parseColor("#FF5252")));
            logoutBtn.setOnClickListener(v -> {
                renewEnabled = false;
                authEpoch.incrementAndGet();
                bridge.nativeSetFreeMode(false);
                message = "Enter your license key to authenticate.";
                showLoginView();
            });
            settingsView.addView(logoutBtn);
        }
        if (groupHolders[EvTabs.SETTINGS] != null) {
            groupHolders[EvTabs.SETTINGS].removeAllViews();
            groupHolders[EvTabs.SETTINGS].addView(settingsView);
        }
    }

    private String safeString(int which) {
        try {
            switch (which) {
                case 0: return bridge.getTelegramHandle();
                case 1: return bridge.getTelegramUrl();
                case 2: return bridge.getModSubtitle();
                case 3: return bridge.getModCredit();
                case 4: return bridge.getBuyKeyUrl();
                default: return null;
            }
        } catch (Throwable ignored) {
            return null;
        }
    }

    // ============================================================
    //  FEATURE CONTROLS BUILDER (Identical to Menu.java)
    // ============================================================

    private void control(LinearLayout parent, CrmFeatureSpec s) {
        switch (s.type) {
            case "Toggle": {
                Switch toggle = new Switch(activity);
                EvIcons.styleSwitchCard(activity, toggle, s.label);
                toggle.setChecked(bridge.getFeatureValue(s.id) != 0);
                parent.addView(toggle);

                toggle.setOnCheckedChangeListener((btn, value) -> {
                    if (!syncing) {
                        change(s, value ? 1 : 0, value);
                        if (s.id == 19) {
                            if (value) change(CrmFeatureSpec.parse("13_NativeSpinner_Autoplay_Off,V1,V2,V3"), 2, false);
                            refreshQueueControls();
                        }
                    }
                });
                refreshers.add(() -> {
                    boolean val = bridge.getFeatureValue(s.id) != 0;
                    if (toggle.isChecked() != val) toggle.setChecked(val);
                });
                break;
            }

            case "ChoiceGrid":
            case "ColorGrid": {
                LinearLayout card = new LinearLayout(activity);
                card.setOrientation(LinearLayout.VERTICAL);
                EvIcons.styleFeatureCard(activity, card, 52);

                TextView label = new TextView(activity);
                label.setTextColor(EvIcons.TEXT_WHITE);
                label.setTextSize(11.0f);
                label.setPadding(0, 0, 0, dp(6));
                label.setGravity(Gravity.CENTER_VERTICAL);
                label.setText(EvIcons.rowText(activity, s.label));
                EvIcons.applyRowIcon(activity, label, s.label);
                card.addView(label);

                String[] items = s.args[0].split(",");
                String[] colours = "ColorGrid".equals(s.type) && s.args.length > 2 && !s.args[2].isEmpty()
                        ? s.args[2].split(",") : new String[0];
                Button[] buttons = new Button[items.length];
                int columns = items.length == 3 || items.length == 5 ? 2 : 3;

                LinearLayout row = null;
                for (int i = 1; i < items.length; ++i) {
                    if ((i - 1) % columns == 0) {
                        row = new LinearLayout(activity);
                        row.setOrientation(LinearLayout.HORIZONTAL);
                        card.addView(row, new LinearLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                    }
                    final int index = i;
                    Button button = EvIcons.createChoiceButton(activity);
                    buttons[i] = button;
                    if (row != null) row.addView(button, EvIcons.createChoiceButtonParams(activity));

                    button.setOnClickListener(v -> change(s, index, false));
                }

                Runnable refresh = () -> {
                    int val = bridge.getFeatureValue(s.id);
                    for (int i = 1; i < items.length; ++i) {
                        if (buttons[i] == null) continue;
                        boolean active = i == val;
                        int customAccent = 0;
                        if (i <= colours.length) {
                            try { customAccent = Color.parseColor(colours[i - 1]); }
                            catch (IllegalArgumentException ignored) { }
                        }
                        EvIcons.styleChoiceButton(activity, buttons[i], active, customAccent, items[i], s.label);
                    }
                };
                refresh.run();
                refreshers.add(refresh);
                parent.addView(card);
                break;
            }

            case "Spinner":
            case "NativeSpinner": {
                LinearLayout linearLayout = new LinearLayout(activity);
                linearLayout.setOrientation(LinearLayout.VERTICAL);
                EvIcons.styleFeatureCard(activity, linearLayout, 52);

                linearLayout.addView(EvIcons.createRowHeader(activity, s.label));

                Spinner spinner = new Spinner(activity, Spinner.MODE_DROPDOWN);
                spinner.setContentDescription(s.label);

                String[] items = s.args[0].split(",");
                List<String> list = new LinkedList<>(Arrays.asList(items));
                spinner.setAdapter(EvIcons.createSpinnerAdapter(activity, list));
                EvIcons.attachSpinner(activity, linearLayout, spinner);

                int initial = bridge.getFeatureValue(s.id);
                spinner.setSelection(Math.max(0, Math.min(initial, items.length - 1)), false);
                linearLayout.setVisibility(initial < 0 ? View.GONE : View.VISIBLE);

                spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> p, View v, int position, long id) {
                        int current = bridge.getFeatureValue(s.id);
                        if (!syncing && current >= 0 && position != current) change(s, position, false);
                    }
                    @Override public void onNothingSelected(AdapterView<?> p) {}
                });

                refreshers.add(() -> {
                    int value = bridge.getFeatureValue(s.id);
                    linearLayout.setVisibility(value < 0 ? View.GONE : View.VISIBLE);
                    if (value >= 0 && value < items.length && spinner.getSelectedItemPosition() != value) {
                        spinner.setSelection(value, false);
                    }
                });
                parent.addView(linearLayout);
                break;
            }

            case "SeekBar": {
                int min = Integer.parseInt(s.args[0]);
                int max = Integer.parseInt(s.args[1]);
                int defaultVal = s.args.length > 2 ? Math.max(min, Math.min(max, Integer.parseInt(s.args[2]))) : min;

                LinearLayout linearLayout = new LinearLayout(activity);
                featureCard(linearLayout);
                linearLayout.setOrientation(LinearLayout.VERTICAL);
                linearLayout.setGravity(Gravity.START);
                linearLayout.setClipChildren(false);
                linearLayout.setClipToPadding(false);

                final TextView textView = new TextView(activity);
                int currentVal = Math.max(min, Math.min(max, bridge.getFeatureValue(s.id)));
                textView.setText(EvIcons.formatSeekBarLabel(s.label, currentVal, defaultVal));
                EvIcons.styleSeekLabel(activity, textView, s.label);

                SeekBar seekBar = new SeekBar(activity);
                seekBar.setFocusable(false);
                seekBar.setFocusableInTouchMode(false);
                seekBar.setContentDescription(s.label);
                seekBar.setMax(Math.max(1, max - min));
                seekBar.setProgress(Math.max(0, currentVal - min));
                EvIcons.styleSeekBar(activity, seekBar);

                seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar bar, int i, boolean fromUser) {
                        int val = i + min;
                        if (fromUser) change(s, val, false);
                        textView.setText(EvIcons.formatSeekBarLabel(s.label, val, defaultVal));
                    }
                    @Override public void onStartTrackingTouch(SeekBar bar) {}
                    @Override public void onStopTrackingTouch(SeekBar bar) {}
                });

                linearLayout.addView(textView);
                linearLayout.addView(seekBar);

                refreshers.add(() -> {
                    int val = Math.max(min, Math.min(max, bridge.getFeatureValue(s.id)));
                    if (!seekBar.isPressed() && seekBar.getProgress() != val - min) {
                        seekBar.setProgress(val - min);
                    }
                });
                parent.addView(linearLayout);
                break;
            }

            case "Button": {
                Button button = new Button(activity);
                EvIcons.styleFeatureCard(activity, button, 52);
                button.setTextColor(EvIcons.GOLD);
                button.setAllCaps(false);
                button.setText(Html.fromHtml("<b>" + s.label + "</b>"));
                button.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.0f);
                button.setGravity(Gravity.CENTER);
                button.setBackground(EvIcons.cardBackground(activity, SURFACE_COLOR, BTN_COLOR, 10f, 1));
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    button.setElevation(dp(3));
                }
                button.setOnClickListener(v -> change(s, 0, false));
                parent.addView(button);
                break;
            }

            case "ButtonLink": {
                Button button = EvIcons.createLoginActionButton(activity, s.label, false);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40));
                lp.setMargins(0, dp(4), 0, dp(4));
                button.setLayoutParams(lp);
                button.setOnClickListener(v -> EvIcons.openExternalUrl(activity, s.args[0]));
                parent.addView(button);
                break;
            }

            case "Status": {
                TextView status = new TextView(activity);
                EvIcons.styleStatusCard(activity, status);
                status.setText(s.label + ": " + bridge.getFeatureStatus(s.id));
                parent.addView(status);
                refreshers.add(() -> status.setText(s.label + ": " + bridge.getFeatureStatus(s.id)));
                break;
            }

            case "Category":
            case "RichTextView": {
                TextView label = new TextView(activity);
                label.setText(Html.fromHtml(s.label));
                EvIcons.styleRichHint(activity, label);
                parent.addView(label);
                break;
            }

            default:
                break;
        }
    }

    private void featureCard(View view) {
        EvIcons.styleFeatureCard(activity, view, 52);
    }

    // ============================================================
    //  CORE STATE & ANIMATIONS
    // ============================================================

    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            if (closed || menuFailed || activity == null) return;
            try {
                boolean valid = !bridge.isLoginEnabled() || bridge.isKeyAuthenticated();
                if (valid != featuresVisible) {
                    if (valid) showFeaturesView();
                    else showLoginView();
                }
                syncing = true;
                try {
                    for (Runnable refresh : refreshers) refresh.run();
                } finally {
                    syncing = false;
                }
                updateMenuExpiryText();
            } catch (RuntimeException | LinkageError failure) {
                failMenu(failure);
                return;
            }
            if (!menuFailed) main.postDelayed(this, 1000);
        }
    };

    private void failMenu(Throwable failure) {
        Log.e("CrmExternalMenu", "Menu library error", failure);
        menuFailed = true;
        renewEnabled = false;
        authEpoch.incrementAndGet();
        try { bridge.nativeSetFreeMode(false); } catch (Exception ignored) {}
        refreshers.clear();
        main.removeCallbacks(poll);
        if (scrollView != null) {
            scrollView.removeAllViews();
            TextView err = new TextView(activity);
            err.setTextColor(Color.parseColor("#FF5252"));
            err.setTextSize(14);
            err.setPadding(dp(16), dp(16), dp(16), dp(16));
            err.setText("Menu unavailable. Please reinstall the matching loader release.");
            scrollView.addView(err);
        }
    }

    private void change(CrmFeatureSpec s, int value, boolean enabled) {
        if (closed || menuFailed || (bridge.isLoginEnabled() && !bridge.isKeyAuthenticated())) return;
        bridge.Changes(owner, s.id, s.label, value, enabled, "");
        syncing = true;
        try {
            for (Runnable refresh : refreshers) refresh.run();
            refreshQueueControls();
        } finally {
            syncing = false;
        }
    }

    private void postMessage(String value) {
        main.post(() -> {
            if (!closed) {
                message = value;
                if (statusText != null) statusText.setText(value);
            }
        });
    }

    private void updateMenuExpiryText() {
        if (headerViews == null && licenseViews == null) return;
        boolean signedIn = !bridge.isLoginEnabled() || bridge.isKeyAuthenticated();
        EvIcons.applyLicenseState(headerViews, licenseViews, signedIn, signedIn ? bridge.getExpiryDate() : null);
    }

    private void openTelegram(String name) {
        try {
            activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/" + name)));
        } catch (Exception e) {
            postMessage("Cannot open Telegram link");
        }
    }

    private void setExpanded(boolean value) {
        expanded = value;
        if (panel != null) panel.setVisibility(value ? View.VISIBLE : View.GONE);
        if (bubble != null) {
            bubble.setVisibility(value ? View.GONE : View.VISIBLE);
            bubble.setAlpha(logoAlpha());
        }
    }

    private float logoAlpha() {
        return Math.max(0.10f, Math.min(1.0f, logoOpacity / 100.0f));
    }

    private void enableDrag(View handle, View target) {
        handle.setOnTouchListener(new View.OnTouchListener() {
            float x, y, startX, startY;
            boolean moved;

            @Override
            public boolean onTouch(View view, MotionEvent event) {
                if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    x = event.getRawX();
                    y = event.getRawY();
                    startX = target.getX();
                    startY = target.getY();
                    moved = false;
                    return true;
                }
                if (event.getActionMasked() == MotionEvent.ACTION_MOVE) {
                    float dx = event.getRawX() - x;
                    float dy = event.getRawY() - y;
                    moved |= Math.abs(dx) + Math.abs(dy) > dp(8);
                    if (moved && root != null) {
                        target.setX(Math.max(0, Math.min(root.getWidth() - target.getWidth(), startX + dx)));
                        target.setY(Math.max(0, Math.min(root.getHeight() - target.getHeight(), startY + dy)));
                    }
                    return true;
                }
                if (event.getActionMasked() == MotionEvent.ACTION_UP) {
                    if (!moved) view.performClick();
                    return true;
                }
                return event.getActionMasked() == MotionEvent.ACTION_CANCEL;
            }
        });
    }

    private void applyButtonTouchEffect(final View view) {
        if (view == null) return;
        view.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).start();
            } else if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                v.animate().scaleX(1.0f).scaleY(1.0f).setDuration(160).setInterpolator(new OvershootInterpolator(2.2f)).start();
            }
            return false;
        });
    }

    private void playShakeAnimation(View view) {
        if (view == null) return;
        TranslateAnimation shake = new TranslateAnimation(0, dp(8), 0, 0);
        shake.setDuration(45);
        shake.setRepeatCount(5);
        shake.setRepeatMode(Animation.REVERSE);
        view.startAnimation(shake);
    }

    private void startTitleGlowAnimation(final TextView title) {
        if (title == null) return;
        titleGlowAnim = ValueAnimator.ofArgb(
                Color.parseColor("#00E5FF"), // Neon Cyan
                Color.parseColor("#A855F7"), // Purple Glow
                Color.parseColor("#EC4899"), // Hot Pink Glow
                Color.parseColor("#7DD3FC"), // Gold Glow
                Color.parseColor("#10B981"), // Emerald Glow
                Color.parseColor("#00E5FF")  // Loop
        );
        titleGlowAnim.setDuration(4500);
        titleGlowAnim.setRepeatCount(ValueAnimator.INFINITE);
        titleGlowAnim.addUpdateListener(animator -> {
            int col = (int) animator.getAnimatedValue();
            title.setTextColor(col);
            title.setShadowLayer(10.0f, 0, 0, col);
        });
        titleGlowAnim.start();
    }

    private void startPulseAnimation(final TextView serverStatus) {
        if (serverStatus == null) return;
        pulseAnim = ValueAnimator.ofFloat(0.5f, 1.0f);
        pulseAnim.setDuration(1000);
        pulseAnim.setRepeatCount(ValueAnimator.INFINITE);
        pulseAnim.setRepeatMode(ValueAnimator.REVERSE);
        pulseAnim.addUpdateListener(animation -> {
            float alpha = (float) animation.getAnimatedValue();
            serverStatus.setAlpha(alpha);
        });
        pulseAnim.start();
    }

    private void stopAnimators() {
        if (cardBorderAnim != null) {
            cardBorderAnim.cancel();
            cardBorderAnim = null;
        }
        if (titleGlowAnim != null) {
            titleGlowAnim.cancel();
            titleGlowAnim = null;
        }
        if (pulseAnim != null) {
            pulseAnim.cancel();
            pulseAnim = null;
        }
    }

    private int dp(int value) {
        return EvIcons.dp(activity != null ? activity : owner, value);
    }

    private GradientDrawable cardBackground(int fill, int border) {
        return EvIcons.cardBackground(activity != null ? activity : owner, fill, border, 10f, 1);
    }

    private LinearLayout column() {
        LinearLayout v = new LinearLayout(activity);
        v.setOrientation(LinearLayout.VERTICAL);
        return v;
    }

    private static void requireMain() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            throw new IllegalStateException("Menu lifecycle must run on main thread");
        }
    }
}
