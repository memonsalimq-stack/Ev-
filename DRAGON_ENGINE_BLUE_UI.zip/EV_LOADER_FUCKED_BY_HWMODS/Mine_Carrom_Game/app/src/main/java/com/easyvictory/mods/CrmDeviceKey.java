package com.easyvictory.mods;

import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.spec.ECGenParameterSpec;
import org.json.JSONObject;

/** Device proof of possession, NOT app/hardware attestation or authorization. */
final class CrmDeviceKey {
    private static final String ALIAS = "hw.crm.device.v3";
    private CrmDeviceKey() {}

    // Only called inside the bounded background transport worker. Android's
    // provider keeps the private key non-exportable; hardware backing depends
    // on the device. No software-exportable-key or unsigned-request fallback.
    private static synchronized KeyStore store() throws Exception {
        if (Build.VERSION.SDK_INT < 23) throw new GeneralSecurityException("Keystore unavailable");
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        if (!store.containsAlias(ALIAS)) {
            KeyPairGenerator generator = KeyPairGenerator.getInstance("EC", "AndroidKeyStore");
            generator.initialize(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_SIGN)
                .setAlgorithmParameterSpec(new ECGenParameterSpec("secp256r1"))
                .setDigests(KeyProperties.DIGEST_SHA256).build());
            generator.generateKeyPair();
        }
        return store;
    }

    static byte[] authorize(byte[] request) throws GeneralSecurityException {
        try {
            JSONObject wire = new JSONObject(new String(request, StandardCharsets.UTF_8));
            if (wire.length() != 5 || wire.getInt("v") != 3)
                throw new GeneralSecurityException("Invalid request");
            String canonical = "CRM3\n" + wire.getString("nonce") + "\n" + wire.getString("key")
                + "\n" + wire.getString("iv") + "\n" + wire.getString("body");
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(canonical.getBytes(StandardCharsets.US_ASCII));
            StringBuilder hex = new StringBuilder(64);
            for (byte b : digest) hex.append(Character.forDigit((b & 255) >>> 4, 16)).append(Character.forDigit(b & 15, 16));
            KeyStore store = store();
            PrivateKey key = (PrivateKey) store.getKey(ALIAS, null);
            byte[] publicKey = store.getCertificate(ALIAS).getPublicKey().getEncoded();
            if (key == null || !"EC".equals(key.getAlgorithm()) || publicKey.length != 91)
                throw new GeneralSecurityException("Invalid device key");
            String encoded = Base64.encodeToString(publicKey, Base64.NO_WRAP);
            Signature signer = Signature.getInstance("SHA256withECDSA");
            signer.initSign(key);
            signer.update(("CRM3\ndevice-proof\n" + hex + "\n" + encoded).getBytes(StandardCharsets.US_ASCII));
            wire.put("device_key", encoded);
            wire.put("device_proof", Base64.encodeToString(signer.sign(), Base64.NO_WRAP));
            byte[] result = wire.toString().getBytes(StandardCharsets.UTF_8);
            if (result.length > 8192) throw new GeneralSecurityException("Oversized request");
            return result;
        } catch (Exception failure) {
            // Do not expose provider errors, key material or a partially signed request.
            throw new GeneralSecurityException("Device proof unavailable");
        }
    }
}
